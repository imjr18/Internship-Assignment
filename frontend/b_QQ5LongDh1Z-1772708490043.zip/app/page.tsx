'use client'

import { useState, useCallback } from 'react'
import { Navbar } from '@/components/goodfoods/Navbar'
import { ChatArea } from '@/components/goodfoods/ChatArea'
import { ChatInput } from '@/components/goodfoods/ChatInput'
import { ContextPanel } from '@/components/goodfoods/ContextPanel'
import { ConfirmedLeftColumn, ConfirmedRightPanel } from '@/components/goodfoods/ConfirmedView'
import { BrowseScreen } from '@/components/goodfoods/BrowseScreen'
import { buildState, INITIAL_BOOKING_FIELDS } from '@/lib/mock-data'
import type { AppState, UIState, Restaurant } from '@/lib/types'

/* ─────────────────────────────────────────
   Initial app state factory
───────────────────────────────────────── */

function makeBase(): AppState {
  return {
    screen: 'book',
    bookingState: 'GREETING',
    messages: [],
    bookingFields: { ...INITIAL_BOOKING_FIELDS },
    searchResults: [],
    confirmationCode: null,
  }
}

/* ─────────────────────────────────────────
   Prototype state switcher
   (reviewer navigation — minimal, unobtrusive)
───────────────────────────────────────── */

const STATES: { id: UIState; label: string }[] = [
  { id: 1, label: 'Landing' },
  { id: 2, label: 'Conversation' },
  { id: 3, label: 'Confirmed' },
  { id: 4, label: 'Browse' },
]

function StateSwitcher({ active, onChange }: { active: UIState; onChange: (s: UIState) => void }) {
  return (
    <div
      className="fixed flex items-center gap-1.5 z-[200]"
      style={{
        bottom: '24px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(8,8,8,0.92)',
        border: '1px solid #1e1e1e',
        borderRadius: '100px',
        padding: '4px 8px',
        backdropFilter: 'blur(8px)',
      }}
      aria-label="Prototype state navigator"
    >
      {STATES.map((s) => (
        <button
          key={s.id}
          onClick={() => onChange(s.id)}
          style={{
            height: '22px',
            padding: '0 10px',
            borderRadius: '100px',
            fontSize: '10px',
            cursor: 'pointer',
            background: active === s.id ? 'rgba(201,169,110,0.12)' : 'transparent',
            color: active === s.id ? '#504a44' : '#2d2d2d',
            border: `1px solid ${active === s.id ? '#2d2d2d' : 'transparent'}`,
            fontFamily: 'inherit',
            transition: 'all 150ms',
          }}
          onMouseEnter={(e) => { if (active !== s.id) e.currentTarget.style.color = '#504a44' }}
          onMouseLeave={(e) => { if (active !== s.id) e.currentTarget.style.color = '#2d2d2d' }}
        >
          {s.label}
        </button>
      ))}
    </div>
  )
}

/* ─────────────────────────────────────────
   Main Page
───────────────────────────────────────── */

export default function Page() {
  const [uiState, setUiState] = useState<UIState>(1)
  const [appState, setAppState] = useState<AppState>(() => ({
    ...makeBase(),
    ...buildState(1),
  }))
  const [prefill, setPrefill] = useState<string | undefined>(undefined)

  /* Switch prototype state */
  function handleStateChange(s: UIState) {
    setUiState(s)
    setPrefill(undefined)
    setAppState({ ...makeBase(), ...buildState(s) })
  }

  /* Navigate between book / browse */
  const handleNavigate = useCallback((screen: 'book' | 'browse') => {
    const next: UIState = screen === 'browse' ? 4 : 1
    setUiState(next)
    setAppState({ ...makeBase(), ...buildState(next) })
  }, [])

  /* Guest sends a message */
  const handleSend = useCallback((message: string) => {
    setPrefill(undefined)
    setAppState((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        { id: Math.random().toString(36).slice(2), role: 'user', content: message },
      ],
    }))
  }, [])

  /* Suggestion card clicked — prefill and focus input */
  const handleSuggestion = useCallback((message: string) => {
    setPrefill(message)
  }, [])

  /* Context panel interactions */
  const handleCheckAvailability = useCallback((restaurant: Restaurant) => {
    setAppState((prev) => ({
      ...prev,
      bookingFields: { ...prev.bookingFields, restaurant: restaurant.name },
    }))
  }, [])

  const handleSelectRestaurant = useCallback((restaurant: Restaurant) => {
    setAppState((prev) => ({
      ...prev,
      bookingFields: { ...prev.bookingFields, restaurant: restaurant.name },
    }))
  }, [])

  /* New reservation from confirmation screen */
  const handleNewReservation = useCallback(() => {
    setUiState(1)
    setAppState({ ...makeBase(), ...buildState(1) })
    setPrefill(undefined)
  }, [])

  /* Book from browse screen — navigate to chat with restaurant pre-selected */
  const handleBookRestaurant = useCallback((restaurant: Restaurant) => {
    setUiState(1)
    setPrefill(`I'd like to make a reservation at ${restaurant.name}.`)
    setAppState({
      ...makeBase(),
      screen: 'book',
      bookingState: 'GREETING',
      bookingFields: { ...INITIAL_BOOKING_FIELDS, restaurant: restaurant.name },
    })
  }, [])

  const isConfirmed = appState.bookingState === 'COMPLETED' && appState.confirmationCode !== null

  return (
    <>
      <Navbar onNavigate={handleNavigate} />

      <main style={{ paddingTop: '60px', minHeight: '100vh' }}>
        {/* ── Browse screen (full-width) ── */}
        {appState.screen === 'browse' ? (
          <BrowseScreen
            onBookRestaurant={handleBookRestaurant}
            defaultOpenId={uiState === 4 ? 'rest-001' : null}
          />
        ) : isConfirmed ? (
          /* ── Confirmation screen (chat replaced) ── */
          <div className="flex" style={{ minHeight: 'calc(100vh - 60px)' }}>
            <ConfirmedLeftColumn
              confirmationCode={appState.confirmationCode!}
              bookingFields={appState.bookingFields}
              onNewReservation={handleNewReservation}
            />
            <ConfirmedRightPanel bookingFields={appState.bookingFields} />
          </div>
        ) : (
          /* ── Normal booking experience ── */
          <div className="flex" style={{ minHeight: 'calc(100vh - 60px)' }}>
            {/* Left column — 55% */}
            <div
              style={{
                width: '55%',
                display: 'flex',
                flexDirection: 'column',
                minHeight: 'calc(100vh - 60px)',
              }}
            >
              <ChatArea
                state={appState}
                onSend={handleSend}
                onSuggestion={handleSuggestion}
                prefill={prefill}
              />
            </div>

            {/* Right column — 45% */}
            <ContextPanel
              state={appState}
              onCheckAvailability={handleCheckAvailability}
              onSelectRestaurant={handleSelectRestaurant}
            />
          </div>
        )}
      </main>

      {/* Prototype navigator — reviewer only */}
      <StateSwitcher active={uiState} onChange={handleStateChange} />
    </>
  )
}
